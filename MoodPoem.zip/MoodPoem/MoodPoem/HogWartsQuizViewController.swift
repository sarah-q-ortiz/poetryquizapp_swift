//
//  HogWartsQuizViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/2/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class HogWartsQuizViewController: UIViewController {
    var slytherinButtonImages: [UIImage] = [UIImage(named: "theColonel")!, UIImage(named: "funeral")!, UIImage(named: "metroStation")!, UIImage(named: "theBear")!, UIImage(named: "america")!, UIImage(named: "inWhite")!, UIImage(named: "winterSundays")!]
    var hufflepuffButtonImages: [UIImage] = [UIImage(named: "spider")!, UIImage(named: "essentialOils")!, UIImage(named: "supermarket")!, UIImage(named: "poorOldWoman")!, UIImage(named: "queenChristina")!, UIImage(named: "fillingStation")!, UIImage(named: "forColoredGirls")!]
    var ravenclawButtonImages: [UIImage] = [UIImage(named: "grasshopper")!, UIImage(named: "weRealCool")!, UIImage(named: "goldenShovel")!, UIImage(named: "totemSonnets")!, UIImage(named: "Design")!, UIImage(named: "loveSong")!, UIImage(named: "bilingual")!]
    var gryffindorButtonImages: [UIImage] = [UIImage(named: "songOfMyself")!, UIImage(named: "defendingWalt")!, UIImage(named: "redWheelBarrow")!, UIImage(named: "persimmons")!, UIImage(named: "newColossus")!, UIImage(named: "montage")!, UIImage(named: "sundayMorning")!]
    var slytherinTraits = 0
    var hufflepuffTraits = 0
    var ravenclawTraits = 0
    var gryffindorTraits = 0
    var answerCount = 0
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var hufflepuffButton: UIButton!
    @IBAction func hufflepuffButton(_ sender: Any) {
        answerCount += 1
        hufflepuffTraits += 1
        changePics()
    }
    @IBOutlet weak var ravenclawButton: UIButton!
    @IBAction func ravenclawButton(_ sender: Any) {
        answerCount += 1
        ravenclawTraits += 1
        changePics()
    }
    @IBOutlet weak var gryffindorButton: UIButton!
    @IBAction func gryffindorButton(_ sender: Any) {
        answerCount += 1
        gryffindorTraits += 1
        changePics()
    }
    @IBOutlet weak var slytherinButton: UIButton!
    @IBAction func slytherinButton(_ sender: Any) {
        slytherinTraits += 1
        answerCount += 1
        changePics()
        
    }
    @IBAction func goHomeButt(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    func changePics(){
        if answerCount < slytherinButtonImages.count{
            slytherinButton.setImage(slytherinButtonImages[answerCount], for: .normal )
            ravenclawButton.setImage(ravenclawButtonImages[answerCount], for: .normal)
            hufflepuffButton.setImage(hufflepuffButtonImages[answerCount], for: .normal)
            gryffindorButton.setImage(gryffindorButtonImages[answerCount], for: .normal)
        } else {
            quizResults()
        }
        
    }
    func quizResults (){
        if gryffindorTraits > slytherinTraits && gryffindorTraits > ravenclawTraits && gryffindorTraits > hufflepuffTraits {
            resultLabel.text = "You are a Gryffindor!"
            resultLabel.textColor = .red
            gryffindorButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            slytherinButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            ravenclawButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            hufflepuffButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
           
           
        } else if slytherinTraits > gryffindorTraits && slytherinTraits > ravenclawTraits && slytherinTraits > hufflepuffTraits{
            resultLabel.text = "You are a Slytherin!"
            resultLabel.textColor = .green
            gryffindorButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            slytherinButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            ravenclawButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            hufflepuffButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
        } else if ravenclawTraits > gryffindorTraits && ravenclawTraits > slytherinTraits && ravenclawTraits > hufflepuffTraits{
            resultLabel.text = "You are a Ravenclaw!"
            resultLabel.textColor = .blue
            gryffindorButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            slytherinButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            ravenclawButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            hufflepuffButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
        } else {
            resultLabel.text = "You are a HufflePuff!"
            resultLabel.textColor = .yellow
            gryffindorButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            slytherinButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            ravenclawButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
            hufflepuffButton.setImage(UIImage(named: "smol hogwarts"), for: .normal)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        slytherinButton.setImage(slytherinButtonImages[0], for: .normal)
        ravenclawButton.setImage(ravenclawButtonImages[0], for: .normal)
        hufflepuffButton.setImage(hufflepuffButtonImages[0], for: .normal)
        gryffindorButton.setImage(gryffindorButtonImages[0], for: .normal)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
