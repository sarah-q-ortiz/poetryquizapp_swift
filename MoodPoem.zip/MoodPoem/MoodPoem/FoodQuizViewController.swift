//
//  FoodQuizViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/3/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class FoodQuizViewController: UIViewController {

    struct Poem {
        let title: String
        let author: String
        let url: String
    }
    let sweetFoodPoems: [Poem] =
        [Poem(title: "A Spider sewed at Night", author: "Emily Dickinson", url: "http://www.bartleby.com/113/2027.html"),
         Poem(title: "Essential Oils are Wrung", author: "Emily Dickinson", url: "http://www.bartleby.com/113/4065.html"),
         Poem(title: "A Supermarket in California", author: "Allen Ginsberg", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/47660"),
         Poem(title: "Queen Christina", author: "Randall Mann", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/55024"),
         Poem(title: "Filling Station", author: "Elizabeth Bishop", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/52193"),
         Poem(title: "Bilingual Sestina", author: "Julia Alvarez", url: "https://wise.willamette.edu/access/content/group/ENGL-116W-01-18_FA/Alvarez%20-%20Bilingual%20Sestina.pdf"),
         Poem(title: "A Visit from St. Nicholas", author: "Clement Clark Moore", url: "https://www.poets.org/poetsorg/poem/visit-st-nicholas")]
    let savoryFoodPoems: [Poem] =
        [Poem(title: "The Colonel", author: "Carolyn Forché", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/49862"),
         Poem(title: "Defending Walt Whitman", author: "Sherman Alexie", url: "http://www.bpj.org/poems/alexie_whitman.html"),
         Poem(title: "The Golden Shovel", author: "Terrance Hayes", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/55678"),
         Poem(title: "The Bear", author: "Galway Kinnell", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/42679"),
         Poem(title: "America", author: "Claude McKay", url: "https://shenandoahliterary.org/blog/2014/03/america-by-claude-mckay-1921/"),
         Poem(title: "Totem Sonnets", author: "Sherman Alexie", url: "https://wise.willamette.edu/access/content/group/ENGL-116W-01-18_FA/Sherman%20Alexie%2C%20__Totem%20Sonnets__.pdf"),
         Poem(title: "The Love Song of J. Alfred Prufrock", author: "T.S. Eliot", url: "https://www.poetryfoundation.org/poetrymagazine/poems/detail/44212")]
    let fruitPoems: [Poem] =
        [Poem(title: "R-p-o-p-h-e-s-s-g-r", author: "EE Cummings", url: "https://www.poets.org/poetsorg/poem/r-p-o-p-h-e-s-s-g-r"),
         Poem(title: "Song of Myself", author: "Walt Whitman", url: "https://www.poets.org/poetsorg/poem/song-myself-xi"),
         Poem(title: "The Red Wheelbarrow", author: "William Carlos Williams", url: "http://www.poetryfoundation.org/resources/learning/core-poems/detail/45502"),
         Poem(title: "To a Poor Old Woman", author: "William Carlos Williams", url: "https://www.poets.org/poetsorg/poem/poor-old-woman"),
         Poem(title: "In White", author: "Robert Frost", url: "https://www.poemhunter.com/poem/in-white/"),
         Poem(title: "For Colored Girls", author: "Ntozake Shange", url: "https://www.amazon.com/Colored-Girls-Considered-Suicide-Rainbow/dp/0684843269"),
         Poem(title: "Sunday Morning", author: "Wallace Stevens", url: "https://www.poets.org/poetsorg/poem/sunday-morning")]
    let veggiePoems: [Poem] =
        [Poem(title: "I felt a Funeral, in my Brain", author: "Emily Dickinson", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/45706"),
         Poem(title: "We Real Cool", author: "Gwendolyn Brooks", url: "https://www.poetryfoundation.org/poetrymagazine/poems/detail/28112"),
         Poem(title: "In a Station of the Metro", author: "Ezra Pound", url: "https://www.poets.org/poetsorg/poem/station-metro"),
         Poem(title: "Persimmons", author: "Li-Young Lee", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/43011"),
         Poem(title: "The New Colossus", author: "Emma Lazarus", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/46550"),
         Poem(title: "Design", author: "Robert Frost", url: "https://www.poets.org/poetsorg/poem/design"),
         Poem(title: "Those Winter Sundays", author: "Robert Hayden", url: "https://www.poets.org/poetsorg/poem/those-winter-sundays")]
    func poemConfig(_ poem: Poem) -> String{
        let author = poem.author
        let title = poem.title
        return "\(title)\n \(author)"
    }
    
    var sweetFoodImages: [UIImage] = [UIImage(named: "cheesecake")!, UIImage(named: "chocCake")!, UIImage(named: "carmelbar")!, UIImage(named: "smoreo")!, UIImage(named: "carmelpineapple")!, UIImage(named: "chocIce")!, UIImage(named: "churros")!]
    var savoryFoodImages: [UIImage] = [UIImage(named: "burger")!, UIImage(named: "burrito")!, UIImage(named: "ramen")!, UIImage(named: "macNCheese")!, UIImage(named: "pasta")!, UIImage(named: "kebab")!, UIImage(named: "pizza")!]
    var fruitImages: [UIImage] = [UIImage(named: "strawberries")!, UIImage(named: "blueberries")!, UIImage(named: "apples")!, UIImage(named: "grapes")!, UIImage(named: "pineapple")!, UIImage(named: "peaches")!, UIImage(named: "bananas")!]
    var vegetableImages: [UIImage] = [UIImage(named: "corn")!, UIImage(named: "bellpeppers")!, UIImage(named: "avocado")!, UIImage(named: "cucumbers")!, UIImage(named: "tomatoes")!, UIImage(named: "brocoli")!, UIImage(named: "salad")!]
    var sweetFoodTraits = 0
    var savoryFoodTraits = 0
    var fruitTraits = 0
    var vegatableTraits = 0
    var answerCount = 0
    var indexNum = 0
    var pURL = ""
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var sweetFoodButton: UIButton!
    @IBAction func sweetFoodButton(_ sender: Any) {
        answerCount += 1
        sweetFoodTraits += 1
        changePics()
    }
    @IBOutlet weak var savoryFoodButton: UIButton!
    @IBAction func savoryFoodButton(_ sender: Any) {
        answerCount += 1
        savoryFoodTraits += 1
        changePics()
    }
    @IBOutlet weak var fruitButton: UIButton!
    @IBAction func fruitButton(_ sender: Any) {
        answerCount += 1
        fruitTraits += 1
        changePics()
    }
    @IBOutlet weak var vegetableButton: UIButton!
    @IBAction func vegetableButton(_ sender: Any) {
        vegatableTraits += 1
        answerCount += 1
        changePics()
        
    }
    
    func changePics(){
        if answerCount < sweetFoodImages.count{
            sweetFoodButton.setImage(sweetFoodImages[answerCount], for: .normal )
            savoryFoodButton.setImage(savoryFoodImages[answerCount], for: .normal)
            fruitButton.setImage(fruitImages[answerCount], for: .normal)
            vegetableButton.setImage(vegetableImages[answerCount], for: .normal)
        } else {
            quizResults()
        }
        
    }
    
    
    func quizResults () {
        if vegatableTraits > sweetFoodTraits && vegatableTraits > fruitTraits && vegatableTraits > savoryFoodTraits {
            indexNum = Int((arc4random() % UInt32(veggiePoems.count)))
            resultLabel.text = "You are a Hearty Veggie!Read:\n \(poemConfig(veggiePoems[indexNum]))"
            resultLabel.textColor = .green
            //url = NSURL(string: veggiePoems[indexNum].url)!
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            fruitButton.setImage(UIImage(named: "corn"), for: .normal)
            vegetableButton.setImage(UIImage(named: "brocoli"), for: .normal)
            savoryFoodButton.setImage(UIImage(named: "bellpeppers"), for: .normal)
            sweetFoodButton.setImage(UIImage(named: "cucumbers"), for: .normal)
            pURL += veggiePoems[indexNum].url
            
        } else if sweetFoodTraits > vegatableTraits && sweetFoodTraits > fruitTraits && sweetFoodTraits > savoryFoodTraits{
            indexNum = Int((arc4random() % UInt32(sweetFoodPoems.count)))
            resultLabel.text = "You're a Decadent Delight Read:\n \(poemConfig(sweetFoodPoems[indexNum]))"
            resultLabel.textColor = .purple
           // url = NSURL(string: sweetFoodPoems[indexNum].url)!
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            fruitButton.setImage(UIImage(named: "churros"), for: .normal)
            vegetableButton.setImage(UIImage(named: "chocIce"), for: .normal)
            savoryFoodButton.setImage(UIImage(named: "chocCake"), for: .normal)
            sweetFoodButton.setImage(UIImage(named: "carmelbar"), for: .normal)
            pURL += sweetFoodPoems[indexNum].url
        } else if fruitTraits > vegatableTraits && fruitTraits > sweetFoodTraits && fruitTraits > savoryFoodTraits{
            indexNum = Int((arc4random() % UInt32(veggiePoems.count)))
            resultLabel.text = "You're a Fruity Cutey! Read:\n \(poemConfig(fruitPoems[indexNum]))"
            resultLabel.textColor = .blue
           // url = NSURL(string: fruitPoems[indexNum].url)!
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            fruitButton.setImage(UIImage(named: "strawberries"), for: .normal)
            vegetableButton.setImage(UIImage(named: "apples"), for: .normal)
            savoryFoodButton.setImage(UIImage(named: "blueberries"), for: .normal)
            sweetFoodButton.setImage(UIImage(named: "peaches"), for: .normal)
            pURL += fruitPoems[indexNum].url
        } else {
            indexNum = Int((arc4random() % UInt32(veggiePoems.count)))
            resultLabel.text = "A Savory Saviour Read:\n \(poemConfig(savoryFoodPoems[indexNum]))"
            resultLabel.textColor = .yellow
            //url = NSURL(string: savoryFoodPoems[indexNum].url)!
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            fruitButton.setImage(UIImage(named: "pizza"), for: .normal)
            vegetableButton.setImage(UIImage(named:"pasta"), for: .normal)
            savoryFoodButton.setImage(UIImage(named: "burrito"), for: .normal)
            sweetFoodButton.setImage(UIImage(named: "ramen"), for: .normal)
            pURL += savoryFoodPoems[indexNum].url
        }
    }
    
    @IBOutlet weak var openURLButton: UIButton!
    @IBAction func openURLButton(_ sender: Any) {
        if let url = NSURL(string: pURL){
            UIApplication.shared.open(url as URL, options: [:] , completionHandler: nil)
        }
    }
    @IBAction func goHomeButton(_ sender: Any) {
        reset()
        dismiss(animated: true, completion: nil)
        
    }
    func reset(){
        indexNum = 0
        answerCount = 0
        sweetFoodTraits = 0
        savoryFoodTraits = 0
        fruitTraits = 0
        vegatableTraits = 0
        pURL = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        sweetFoodButton.setImage(sweetFoodImages[0], for: .normal)
        savoryFoodButton.setImage(savoryFoodImages[0], for: .normal)
        fruitButton.setImage(fruitImages[0], for: .normal)
        vegetableButton.setImage(vegetableImages[0], for: .normal)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
