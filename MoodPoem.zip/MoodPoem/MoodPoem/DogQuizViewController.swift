//
//  ColorQuizViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/3/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class DogQuizViewController: UIViewController {
    var xlDogPoems: [UIImage] = [UIImage(named: "theColonel")!, UIImage(named: "defendingWalt")!, UIImage(named: "weRealCool")!, UIImage(named: "theBear")!, UIImage(named: "america")!, UIImage(named: "bilingual")!, UIImage(named: "sundayMorning")!]
    var largeDogPoems: [UIImage] = [UIImage(named: "funeral")!, UIImage(named: "metroStation")!, UIImage(named: "poorOldWoman")!, UIImage(named: "totemSonnets")!, UIImage(named: "forColoredGirls")!, UIImage(named: "winterSundays")!, UIImage(named: "persimmons")!]
    var mediumDogPoems: [UIImage] = [UIImage(named: "spider")!, UIImage(named: "essentialOils")!, UIImage(named: "supermarket")!, UIImage(named: "newColossus")!, UIImage(named: "inWhite")!, UIImage(named: "montage")!, UIImage(named: "loveSong")!]
    var smallDogPoems: [UIImage] = [UIImage(named: "grasshopper")!, UIImage(named: "electric")!, UIImage(named: "songOfMyself")!, UIImage(named: "redWheelBarrow")!, UIImage(named: "fillingStation")!, UIImage(named: "visit")!, UIImage(named: "Design")!]
    var xlDogTraits = 0
    var largeDogTraits = 0
    var mediumDogTraits = 0
    var smallDogTraits = 0
    var answerCount = 0
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var xlDogButton: UIButton!
    @IBAction func xlDogButton(_ sender: Any) {
        answerCount += 1
        xlDogTraits += 1
        changePics()
    }
    @IBOutlet weak var largeDogButton: UIButton!
    @IBAction func largeDogButton(_ sender: Any) {
        answerCount += 1
        largeDogTraits += 1
        changePics()
    }
    @IBOutlet weak var mediumDogButton: UIButton!
    @IBAction func mediumDogButton(_ sender: Any) {
        answerCount += 1
        mediumDogTraits += 1
        changePics()
    }
    @IBOutlet weak var smallDogButton: UIButton!
    @IBAction func smallDogButton(_ sender: Any) {
        smallDogTraits += 1
        answerCount += 1
        changePics()
        
    }
    
    func changePics(){
        if answerCount < xlDogPoems.count{
            xlDogButton.setImage(xlDogPoems[answerCount], for: .normal )
            largeDogButton.setImage(largeDogPoems[answerCount], for: .normal)
            mediumDogButton.setImage(mediumDogPoems[answerCount], for: .normal)
            smallDogButton.setImage(smallDogPoems[answerCount], for: .normal)
        } else {
            quizResults()
        }
        
    }
    func quizResults (){
        if smallDogTraits > xlDogTraits && smallDogTraits > mediumDogTraits && smallDogTraits > largeDogTraits {
            resultLabel.text = "a v v smol bby!!"
            resultLabel.textColor = .red
            mediumDogButton.setImage(UIImage(named: "smallboi1"), for: .normal)
            smallDogButton.setImage(UIImage(named: "smallboi2"), for: .normal)
            largeDogButton.setImage(UIImage(named: "smallboi3"), for: .normal)
            xlDogButton.setImage(UIImage(named: "smallboi4"), for: .normal)
            
            
        } else if xlDogTraits > smallDogTraits && xlDogTraits > mediumDogTraits && xlDogTraits > largeDogTraits{
            resultLabel.text = "the v BIGGEST n best BOI"
            resultLabel.textColor = .purple
            mediumDogButton.setImage(UIImage(named: "bigboi1"), for: .normal)
            smallDogButton.setImage(UIImage(named: "bigboi2"), for: .normal)
            largeDogButton.setImage(UIImage(named: "bigboi3"), for: .normal)
            xlDogButton.setImage(UIImage(named: "bigboi4"), for: .normal)
        } else if mediumDogTraits > smallDogTraits && mediumDogTraits > xlDogTraits && mediumDogTraits > largeDogTraits{
            resultLabel.text = "a v v good boi"
            resultLabel.textColor = .blue
            mediumDogButton.setImage(UIImage(named: "medboi5"), for: .normal)
            smallDogButton.setImage(UIImage(named: "medboi6"), for: .normal)
            largeDogButton.setImage(UIImage(named: "medboi7"), for: .normal)
            xlDogButton.setImage(UIImage(named: "medboi8"), for: .normal)
        } else {
            resultLabel.text = "a v good n big boi"
            resultLabel.textColor = .yellow
            mediumDogButton.setImage(UIImage(named: "medboi1"), for: .normal)
            smallDogButton.setImage(UIImage(named:"medboi2"), for: .normal)
            largeDogButton.setImage(UIImage(named: "medboi3"), for: .normal)
            xlDogButton.setImage(UIImage(named: "medboi4"), for: .normal)
        }
    }
    @IBAction func goHomeButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        xlDogButton.setImage(xlDogPoems[0], for: .normal)
        largeDogButton.setImage(largeDogPoems[0], for: .normal)
        mediumDogButton.setImage(mediumDogPoems[0], for: .normal)
        smallDogButton.setImage(smallDogPoems[0], for: .normal)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
