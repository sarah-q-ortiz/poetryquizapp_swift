//
//  MoodQuizControllerViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/2/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class MoodQuizControllerViewController: UIViewController {
    struct Poem {
        let title: String
        let author: String
        let url: String
    }
    let pCalmPoems: [Poem] =
        [Poem(title: "A Spider sewed at Night", author: "Emily Dickinson", url: "https://www.bartleby.com/113/2027.html"),
         Poem(title: "Essential Oils are Wrung", author: "Emily Dickinson", url: "https://www.bartleby.com/113/4065.html"),
         Poem(title: "To a Poor Old Woman", author: "William Carlos Williams", url: "https://www.poets.org/poetsorg/poem/poor-old-woman"),
         Poem(title: "Totem Sonnets", author: "Sherman Alexie", url: "https://wise.willamette.edu/access/content/group/ENGL-116W-01-18_FA/Sherman%20Alexie%2C%20__Totem%20Sonnets__.pdf"),
         Poem(title: "Filling Station", author: "Elizabeth Bishop", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/52193"),
         Poem(title: "In White", author: "Robert Frost", url: "https://www.poemhunter.com/poem/in-white/"),
         Poem(title: "A Visit from St. Nicholas", author: "Clement Clark Moore", url: "https://www.poets.org/poetsorg/poem/visit-st-nicholas")]
    let pEnergyPoems: [Poem] =
        [Poem(title: "r-p-o-p-h-e-s-s-g-r", author: "EE Cummings", url: "https://www.poets.org/poetsorg/poem/r-p-o-p-h-e-s-s-g-r"),
         Poem(title: "Song of Myself", author: "Walt Whitman", url: "https://www.poets.org/poetsorg/poem/song-myself-xi"),
         Poem(title: "A Supermarket in California", author: "Allen Ginsberg", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/47660"),
         Poem(title: "Defending Walt Whitman", author: "Sherman Alexie", url: "http://www.bpj.org/poems/alexie_whitman.html"),
         Poem(title: "The New Colossus", author: "Emma Lazarus", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/46550"),
         Poem(title: "America", author: "Claude McKay", url: "https://shenandoahliterary.org/blog/2014/03/america-by-claude-mckay-1921/"),
         Poem(title: "Bilingual Sestina", author: "Julia Alvarez", url: "https://wise.willamette.edu/access/content/group/ENGL-116W-01-18_FA/Alvarez%20-%20Bilingual%20Sestina.pdf")]
    let uCalmPoems: [Poem] =
        [Poem(title: "I felt a Funeral, in my Brain", author: "Emily Dickinson", url: "https://www.poetryfoundation.org/poems/45706/i-felt-a-funeral-in-my-brain-340"),
         Poem(title: "In a Station of the Metro", author: "Ezra Pound", url: "https://www.poets.org/poetsorg/poem/station-metro"),
         Poem(title: "The Red Wheelbarrow", author: "William Carlos Williams", url: "http://www.poetryfoundation.org/resources/learning/core-poems/detail/45502"),
         Poem(title: "Persimmons", author: "Li-Young Lee", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/43011"),
         Poem(title: "Queen Christina", author: "Randall Mann", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/55024"),
         Poem(title: "Design", author: "Robert Frost", url: "https://www.poets.org/poetsorg/poem/design"),
         Poem(title: "For Colored Girls", author: "Ntozake Shange", url: "https://www.amazon.com/Colored-Girls-Considered-Suicide-Rainbow/dp/0684843269")]
    let uEnergyPoems: [Poem] =
        [Poem(title: "The Colonel", author: "Emily Dickinson", url: "https://www.poetryfoundation.org/poems/49862/the-colonel"),
         Poem(title: "We Real Cool", author: "Gwendolyn Brooks", url: "https://www.poetryfoundation.org/poetrymagazine/poems/detail/28112"),
         Poem(title: "The Golden Shovel", author: "Terrence Hayes", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/55678"),
         Poem(title: "The Bear", author: "Galway Kinnell", url: "https://www.poetryfoundation.org/poems-and-poets/poems/detail/42679"),
         Poem(title: "Skinhead", author: "Patricia Smith", url: "http://www.bu.edu/agni/poetry/print/2002/56-smithp.html"),
         Poem(title: "The Love Song of J. Alfred Prufrock", author: "T.S. Eliot", url: "https://www.poetryfoundation.org/poetrymagazine/poems/detail/44212"),
         Poem(title: "Montage of a Dream Deferred", author: "Langston Hughes", url: "http://library.globalchalet.net/Authors/Poetry%20Books%20Collection/The%20Collected%20Poems%20of%20Langston%20Hughes.pdf")]
    func poemConfig(_ poem: Poem) -> String{
        let author = poem.author
        let title = poem.title
        return "\(title)\n \(author)"
    }
    var pleasantCalmImages: [UIImage] = [UIImage(named: "pCalmBeach")!, UIImage(named: "pCalmNook")!, UIImage(named: "pCalmGar")!, UIImage(named: "pCalmMount")!, UIImage(named: "pCalmTran")!, UIImage(named: "pCalmOff")!, UIImage(named: "pCalmCon")!]
    var pleasantEnergeticImages: [UIImage] = [UIImage(named: "pEnergBeach")!, UIImage(named: "pEnergNook")!, UIImage(named: "pEnergGar")!, UIImage(named: "pEnergMount")!, UIImage(named: "pEnergTran")!, UIImage(named: "pEnergOff")!, UIImage(named: "pEnergCon")!]
    var unpleasantCalmImages: [UIImage] = [UIImage(named: "uCalmBeach")!, UIImage(named: "uCalmNook")!, UIImage(named: "uCalmGar")!, UIImage(named: "uCalmMount")!, UIImage(named: "uCalmTran")!, UIImage(named: "uCalmOff")!, UIImage(named: "uCalmCon")!]
    var unpleasantEnergeticImages: [UIImage] = [UIImage(named: "uEnergBeach")!, UIImage(named: "uEnergNook")!, UIImage(named: "uEnergGar")!, UIImage(named: "uEnergMount")!, UIImage(named: "uEnergTran")!, UIImage(named: "uEnergOff")!, UIImage(named: "uEnergCon")!]
    
    var pleasantCalmTraits = 0
    var pleasantEnergeticTraits = 0
    var unpleasantCalmTraits = 0
    var unpleasantEnergeticTraits = 0
    var answerCount = 0
    var indexNum = 0
    var pURL = ""
    @IBOutlet weak var openURLButton: UIButton!
    @IBAction func openURLButton(_ sender: Any) {
        if let url = NSURL(string: pURL){
            UIApplication.shared.open(url as URL, options: [:] , completionHandler: nil)
        }
    }
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var pleasantCalmButton: UIButton!
    @IBAction func pleasantCalmButton(_ sender: Any) {
        answerCount += 1
        pleasantCalmTraits += 1
        changePics()
    }
    @IBOutlet weak var pleasantEnergeticButton: UIButton!
    @IBAction func pleasantEnergeticButton(_ sender: Any) {
        answerCount += 1
        pleasantEnergeticTraits += 1
        changePics()
    }
    @IBOutlet weak var unpleasantCalmButton: UIButton!
    @IBAction func unpleasantCalmButton(_ sender: Any) {
        answerCount += 1
        unpleasantCalmTraits += 1
        changePics()
    }
    @IBOutlet weak var unpleasantEnergeticButton: UIButton!
    @IBAction func unpleasantEnergeticButton(_ sender: Any) {
        unpleasantEnergeticTraits += 1
        answerCount += 1
        changePics()
        
    }
    
    func changePics(){
        if answerCount < pleasantCalmImages.count{
                pleasantCalmButton.setImage(pleasantCalmImages[answerCount], for: .normal )
            pleasantEnergeticButton.setImage(pleasantEnergeticImages[answerCount], for: .normal)
             unpleasantCalmButton.setImage(unpleasantCalmImages[answerCount], for: .normal)
            unpleasantEnergeticButton.setImage(unpleasantEnergeticImages[answerCount], for: .normal)
        } else {
            quizResults()
        }
        
    }
    
    func quizResults ()  {
        if unpleasantEnergeticTraits > pleasantCalmTraits && unpleasantEnergeticTraits > unpleasantCalmTraits && unpleasantEnergeticTraits > pleasantEnergeticTraits {
            indexNum = Int((arc4random() % UInt32(uEnergyPoems.count)))
            resultLabel.text = "Chaos Reigns inside Read:\n \(poemConfig(uEnergyPoems[indexNum]))"
            resultLabel.textColor = .red
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            unpleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            unpleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pURL += uEnergyPoems[indexNum].url
            
        } else if pleasantCalmTraits > unpleasantEnergeticTraits && pleasantCalmTraits > unpleasantCalmTraits && pleasantCalmTraits > pleasantEnergeticTraits{
            indexNum = Int((arc4random() % UInt32(uEnergyPoems.count)))
            resultLabel.text = "Contentment is Key Read:\n \(poemConfig(pCalmPoems[indexNum]))"
            resultLabel.textColor = .purple
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            unpleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            unpleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pURL +=  pCalmPoems[indexNum].url
        } else if unpleasantCalmTraits > unpleasantEnergeticTraits && unpleasantCalmTraits > pleasantCalmTraits && unpleasantCalmTraits > pleasantEnergeticTraits{
            indexNum = Int((arc4random() % UInt32(uEnergyPoems.count)))
            resultLabel.text = "Its ok to be sad Read:\n \(poemConfig(uCalmPoems[indexNum]))"
            resultLabel.textColor = .blue
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            unpleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            unpleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pURL +=  uCalmPoems[indexNum].url
        } else {
            indexNum = Int((arc4random() % UInt32(uEnergyPoems.count)))
            resultLabel.text = "Happy Happy Read:\n \(poemConfig(pEnergyPoems[indexNum]))"
            
            resultLabel.textColor = .yellow
            openURLButton.setTitle("Click Here for Poem", for: .normal)
            openURLButton.setTitleColor(.white, for: .normal)
            unpleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            unpleasantEnergeticButton.setImage(UIImage(named:"smol moodbrain"), for: .normal)
            pleasantEnergeticButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pleasantCalmButton.setImage(UIImage(named: "smol moodbrain"), for: .normal)
            pURL +=  pEnergyPoems[indexNum].url
        }
    }
    @IBAction func goHomeButt(_ sender: Any) {
        reset()
        dismiss(animated: true, completion: nil)
    }
    func reset(){
         pleasantCalmTraits = 0
         pleasantEnergeticTraits = 0
         unpleasantCalmTraits = 0
         unpleasantEnergeticTraits = 0
         answerCount = 0
         indexNum = 0
        pURL = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        pleasantCalmButton.setImage(pleasantCalmImages[0], for: .normal)
        pleasantEnergeticButton.setImage(pleasantEnergeticImages[0], for: .normal)
        unpleasantCalmButton.setImage(unpleasantCalmImages[0], for: .normal)
        unpleasantEnergeticButton.setImage(unpleasantEnergeticImages[0], for: .normal)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
