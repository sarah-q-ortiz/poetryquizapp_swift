//
//  ViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/1/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBAction func holidayQuizButton(_ sender: Any) {
        performSegue(withIdentifier: "holidaySegue", sender: self)
    }
    
    @IBAction func dogQuizButton(_ sender: Any) {
        performSegue(withIdentifier: "dogQuizSeg", sender: self)
    }
    @IBAction func foodQuizButton(_ sender: Any) {
        performSegue(withIdentifier: "foodQuizSeg", sender: self)
    }
    @IBAction func hogwartsQuizButton(_ sender: Any) {
        performSegue(withIdentifier: "hogwartsQuizSeg", sender: self)
    }
    @IBAction func moodQuizButton(_ sender: Any) {
        performSegue(withIdentifier: "moodQuizSeg", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

