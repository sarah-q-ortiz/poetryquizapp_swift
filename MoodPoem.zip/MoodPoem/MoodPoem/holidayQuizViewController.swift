//
//  holidayQuizViewController.swift
//  MoodPoem
//
//  Created by Sarah Ortiz on 12/5/18.
//  Copyright © 2018 Sarah Ortiz. All rights reserved.
//

import UIKit

class holidayQuizViewController: UIViewController {
    var answerCount = 0
    @IBOutlet weak var festiveButton: UIButton!
    var festiveTraits = 0
    let festivePoems: [UIImage] =
        [UIImage(named: "grasshopper")!,
         UIImage(named: "visit")!,
         UIImage(named: "essentialOils")!,
         UIImage(named: "poorOldWoman")!,
         UIImage(named: "supermarket")!,
         UIImage(named: "fillingStation")!,
         UIImage(named: "sundayMorning")!,]
    @IBOutlet weak var idcButton: UIButton!
    var idcTraits = 0
    let idcPoems: [UIImage] =
        [UIImage(named: "weRealCool")!,
         UIImage(named: "forColoredGirls")!,
         UIImage(named: "totemSonnets")!,
         UIImage(named: "queenChristina")!,
         UIImage(named: "inWhite")!,
         UIImage(named: "bilingual")!,
         UIImage(named: "spider")!,]
    @IBOutlet weak var grumpButton: UIButton!
    var grumpTraits = 0
    let grumpPoems: [UIImage] =
        [UIImage(named: "goldenShovel")!,
         UIImage(named: "redWheelBarrow")!,
         UIImage(named: "winterSundays")!,
         UIImage(named: "theColonel")!,
         UIImage(named: "theBear")!,
         UIImage(named: "metroStation")!,
         UIImage(named: "funeral")!,]
    @IBOutlet weak var foodieButton: UIButton!
    var foodieTraits = 0
    let foodiePoems: [UIImage] =
        [UIImage(named: "america")!,
         UIImage(named: "newColossus")!,
         UIImage(named: "montage")!,
         UIImage(named: "defendingWalt")!,
         UIImage(named: "songOfMyself")!,
         UIImage(named: "Design")!,
         UIImage(named: "persimmons")!,]
    @IBAction func festiveButton(_ sender: Any) {
        festiveTraits += 1
        answerCount += 1
        updatePics()
    }
    
    @IBAction func idcButton(_ sender: Any) {
        idcTraits += 1
        answerCount += 1
        updatePics()
    }
    
    @IBAction func grumpButton(_ sender: Any) {
        grumpTraits += 1
        answerCount += 1
        updatePics()
    }
    @IBAction func foodieButton(_ sender: Any) {
        foodieTraits += 1
        answerCount += 1
        updatePics()
    }
    
    @IBOutlet weak var resultLabel: UILabel!
    func updatePics(){
        if answerCount < festivePoems.count {
            festiveButton.setImage(festivePoems[answerCount], for: .normal)
            idcButton.setImage(idcPoems[answerCount], for: .normal)
            grumpButton.setImage(grumpPoems[answerCount], for: .normal)
            foodieButton.setImage(foodiePoems[answerCount], for: .normal)
        }else{
            calcResults()
        }
    }
    func calcResults(){
        if festiveTraits > idcTraits &&
            festiveTraits > grumpTraits &&
            festiveTraits > foodieTraits {
            resultLabel.text = "You're a festive fool!"
            resultLabel.textColor = .red
            festiveButton.setImage(UIImage(named: "menorah"), for: .normal)
            idcButton.setImage(UIImage(named: "kwanzaa"), for: .normal)
            grumpButton.setImage(UIImage(named: "xmasTree"), for: .normal)
            foodieButton.setImage(UIImage(named: "firework"), for: .normal)
        } else if idcTraits > festiveTraits &&
            idcTraits > grumpTraits &&
            idcTraits > foodieTraits {
            resultLabel.text = "It's just another winter to you!"
            resultLabel.textColor = .gray
            festiveButton.setImage(UIImage(named: "ice"), for: .normal)
            idcButton.setImage(UIImage(named: "train"), for: .normal)
            grumpButton.setImage(UIImage(named: "cabins"), for: .normal)
            foodieButton.setImage(UIImage(named: "walkway"), for: .normal)
        } else if grumpTraits > idcTraits &&
            grumpTraits > festiveTraits &&
            grumpTraits > festiveTraits {
            resultLabel.text = "You're a holiday grump!"
            resultLabel.textColor = .green
            festiveButton.setImage(UIImage(named: "grinch"), for: .normal)
            idcButton.setImage(UIImage(named: "grinch"), for: .normal)
            grumpButton.setImage(UIImage(named: "grinch"), for: .normal)
            foodieButton.setImage(UIImage(named: "grinch"), for: .normal)
        } else {
            resultLabel.text = "You're just here for the food!"
            resultLabel.textColor = .yellow
            festiveButton.setImage(UIImage(named: "phatCat"), for: .normal)
            idcButton.setImage(UIImage(named: "phatcat2"), for: .normal)
            grumpButton.setImage(UIImage(named: "phatcat3"), for: .normal)
            foodieButton.setImage(UIImage(named: "phatcat4"), for: .normal)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        festiveButton.setImage(festivePoems[0], for: .normal)
        idcButton.setImage(idcPoems[0], for: .normal)
        grumpButton.setImage(grumpPoems[0], for: .normal)
        foodieButton.setImage(foodiePoems[0], for: .normal)

        // Do any additional setup after loading the view.
    }
    @IBAction func goHomeButt(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
